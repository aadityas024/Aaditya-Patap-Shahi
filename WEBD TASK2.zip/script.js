fetch("https://coding-week-2024-api.onrender.com/api/data")
  .then((data) => {
    console.log(data);
    return data.json();
  })
  .then((fullData) => {
    let myData = "";
    fullData.map((val) => {
      myData += `
    <div  class="box">
            <div><img class="img2" src=${val.image} alt=${val.title} /></div>
            &nbsp;&nbsp;
            <div>
              <div
                style="
                  font-family: sans-serif;
                  font-size: 11px;
                  font-weight: 600;
                
                "
              >
                ${val.headline}
              </div>



<button style="font-size:11px; cursor:pointer;" onClick="openPopup(${val.id})">Read more</button>      
<div id="${val.id}" class="popup">
<p style="padding:5px;  font-family: sans-serif;">${val.content}</p>
<button onClick="closePopup(${val.id})">OK</button>
</div>

              <div
                style="
                  font-family: sans-serif;
                  font-size: 12px;
                  display: flex;
                  justify-content: flex-start;
                  margin-top: 10px;
                "
              >
                <span>
                  <svg
                    style="height: 13px; width: 13px"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    class="w-6 h-6"
                  >
                    <path fill-rule="evenodd" d="M6.75 2.25A.75.75 0 0 1 7.5
                    3v1.5h9V3A.75.75 0 0 1 18 3v1.5h.75a3 3 0 0 1 3 3v11.25a3 3
                    0 0 1-3 3H5.25a3 3 0 0 1-3-3V7.5a3 3 0 0 1 3-3H6V3a.75.75 0
                    0 1 .75-.75Zm13.5 9a1.5 1.5 0 0 0-1.5-1.5H5.25a1.5 1.5 0 0
                    0-1.5 1.5v7.5a1.5 1.5 0 0 0 1.5 1.5h13.5a1.5 1.5 0 0 0
                    1.5-1.5v-7.5Z" clip-rudd" />
                  </svg>
                </span>
                &nbsp;
                <span style="height:10px;">${val.date}</span>
              </div>
            </div>
          </div>
    
    `;
    });
    document.getElementById("cards").innerHTML = myData;
  })
  .catch((err) => {
    console.log(err);
  });

var btn2 = document.getElementById("btn2");
btn2.onclick = function () {
  (btn2.style.background = "black"), (btn2.style.color = "white");
};

function openPopup(a) {
  let b = document.getElementById(a);
  b.classList.add("open-popup");
}
function closePopup(a) {
  let b = document.getElementById(a);
  b.classList.remove("open-popup");
}
